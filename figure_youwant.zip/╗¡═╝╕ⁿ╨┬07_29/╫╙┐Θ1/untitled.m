%%1997-2021
clc;clear;
load('lin.mat');load('year.mat');load('mu.mat');load('yu.mat')
%h = heatmap(lin3);
%h.CellLabelFormat = '%0.2f';
%h.CellLabelColor = 'none';
%h.CellLabelColor = 'none';
%colormap(gca, 'parula');
xname = {'1997-2001','2002-2006','2007-2011','2012-2016','2017-2021'};
yname = {'450','350','250','150','50'};
h = heatmap(xname,yname,lin4);
h.CellLabelFormat = '%0.2f';
h.CellLabelColor = 'none';
colormap(gca, 'parula');
set(0,'defaultAxesFontName','<黑体>');
ylabel('林业产值(亿元)');xlabel('年份');title('林业产业')
%set(gca,'Fontsize',fontsize,'fontname','simsun')
%%
%牧业
x1name = {'1997-2001','2002-2006','2007-2011','2012-2016','2017-2021'};
y1name = {'1700','1350','1000','650','300'};
h1 = heatmap(x1name,y1name,mu);
h1.CellLabelFormat = '%0.2f';
h1.CellLabelColor = 'none';
colormap(gca, 'parula');
set(0,'defaultAxesFontName','<黑体>');
ylabel('牧业产值(亿元)');xlabel('年份');title('牧业产业')
%%
%渔业
x2name = {'1997-2001','2002-2006','2007-2011','2012-2016','2017-2021'};
y2name = {'1800','1425','1050','675','300'};
h2 = heatmap(x2name,y2name,yu);
h2.CellLabelFormat = '%0.2f';
h2.CellLabelColor = 'none';
colormap(gca, 'parula');
set(0,'defaultAxesFontName','<黑体>');
ylabel('渔业产值(亿元)');xlabel('年份');title('渔业产业')
%%
%粮食产量
x3name = {'1997-2001','2002-2006','2007-2011','2012-2016','2017-2021'};
y3name = {'1600','1525','1450','1375','1300'};
h3 = heatmap(x3name,y3name,liang);
h3.CellLabelFormat = '%0.2f';
h3.CellLabelColor = 'none';
colormap(gca, 'parula');
set(0,'defaultAxesFontName','<黑体>');
ylabel('粮食产量(万吨)');xlabel('年份');title('粮食产量')